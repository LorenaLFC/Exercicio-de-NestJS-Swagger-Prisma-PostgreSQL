export class Cliente {
  nome: string;
  telefone: string;
  cpf: string;
  email: string;
  endereco: string;
  numero: string;
  complemento: string;
  bairro: string;
  cidade: string;
  estado: string;
}
